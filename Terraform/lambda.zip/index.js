var request = require('request-promise')

exports.handler = async function(event, context, callback) {
    console.log('start request to Mocky');
    try {
        const res = await request.get('https://i7rkrar2de.execute-api.us-east-1.amazonaws.com/dev/lambda')
        console.log(res)
        callback(null, { statusCode: 200, body: JSON.stringify(res) })
    }
    catch(err) {
        console.error(err.message)
        callback('Got error ' + err.message)
    }
};